//
//  ItemVC.swift
//  tag
//
//  Created by Nirav Zalavadia on 07/06/18.
//  Copyright © 2018 CNSoftNetIndiaPvtLTD. All rights reserved.
//

import UIKit

class ItemVC: UIViewController,UIScrollViewDelegate{

    @IBOutlet weak var attributeTxt: UITextField!
    @IBOutlet weak var itemNameTxt: UITextField!
    
    @IBOutlet weak var locationScrollVw: UIScrollView!
    
    @IBOutlet weak var storeBtn: UIButton!
    
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        
    }

    @IBAction func storeAction(_ sender: Any)
    {
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}
