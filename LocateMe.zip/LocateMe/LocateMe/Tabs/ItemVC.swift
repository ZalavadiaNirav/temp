//
//  ItemVC.swift
//  LocateMe
//
//  Created by Nirav Zalavadia on 06/06/18.
//  Copyright © 2018 CNSoftNetIndiaPvtLTD. All rights reserved.
//

import UIKit
import TagListView

@IBDesignable
class ItemVC: UIViewController, UIScrollViewDelegate,TagListViewDelegate {


    @IBOutlet weak var scrollVw: UIScrollView!
    @IBOutlet weak var addAttributeBtn: UIButton!
    @IBOutlet weak var attributeTxt: UITextField!
    
    @IBOutlet weak var tagListView: TagListView!
    
    @IBAction func addAttributeAction(_ sender: Any)
    {
        
        tagListView.textFont = UIFont.systemFont(ofSize: 24)
        tagListView.textColor = UIColor.white
        tagListView.tagBackgroundColor = UIColor.blue
       
        tagListView.tagLineBreakMode=NSLineBreakMode.byWordWrapping
        tagListView.shadowRadius = 2
        tagListView.shadowOpacity = 0.4
        tagListView.shadowColor = UIColor.black
        tagListView.shadowOffset = CGSize(width: 1, height: 1)
        tagListView.enableRemoveButton=true
        print("frame=\(tagListView.frame)")
        guard attributeTxt.text?.isEmpty==false  else {
            print("Enter attribute")
            return
        }
        
        tagListView.addTag(attributeTxt.text!)
        attributeTxt.text=""
    }
    
    override func viewDidLoad() {
            super.viewDidLoad()
    
            scrollVw.delegate=self
            tagListView.delegate = self
        
        }
        
        override func didReceiveMemoryWarning() {
            super.didReceiveMemoryWarning()
            // Dispose of any resources that can be recreated.
        }
        
        // MARK: TagListViewDelegate
        func tagPressed(_ title: String, tagView: TagView, sender: TagListView) {
            print("Tag pressed: \(title), \(sender)")
            tagView.isSelected = !tagView.isSelected
        }
        
        func tagRemoveButtonPressed(_ title: String, tagView: TagView, sender: TagListView) {
            print("Tag Remove pressed: \(title), \(sender)")
            sender.removeTagView(tagView)
        }

}
