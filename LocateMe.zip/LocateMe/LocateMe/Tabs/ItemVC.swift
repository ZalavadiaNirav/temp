//
//  ItemVC.swift
//  LocateMe
//
//  Created by Nirav Zalavadia on 06/06/18.
//  Copyright © 2018 CNSoftNetIndiaPvtLTD. All rights reserved.
//

import UIKit
import TagListView
import RATreeView


class ItemVC: UIViewController, UIScrollViewDelegate,TagListViewDelegate,RATreeViewDelegate,RATreeViewDataSource
{
   
    var data : [DataObject] = []
    var treeView : RATreeView!
//    var ParticularTree : [DataObject] = []
    var ParticularTree = DataObject(name: "")
    

    @IBOutlet weak var scrollVw: UIScrollView!
    @IBOutlet weak var addAttributeBtn: UIButton!
    @IBOutlet weak var attributeTxt: UITextField!
    
    @IBOutlet weak var attributeTbl: UITableView!
    @IBOutlet weak var tagListView: TagListView!
    
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        data = ItemVC.commonInit()
        self.setupTreeView()

        if(data.count != 0)
        {
            for ind in 0...data.count-1
            {
                let pname = data[ind].name
                if(pname == "Phones")
                {
                    ParticularTree=data[ind]
                }
            }
        }
        print("parent aray=\(ParticularTree)")
        treeView.reloadData()
    }
    
    func setupTreeView() -> Void
    {
        treeView = RATreeView(frame: view.bounds)
        treeView.register(UINib(nibName: String(describing: TreeTableViewCell.self), bundle: nil), forCellReuseIdentifier: String(describing: TreeTableViewCell.self))
        treeView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        treeView.delegate = self;
        treeView.dataSource = self;
        treeView.treeFooterView = UIView()
        treeView.backgroundColor = .clear
        self.view.addSubview(treeView)
    }
    
    @IBAction func addAttributeAction(_ sender: Any)
    {
        guard attributeTxt.text?.isEmpty==false  else {
            print("Enter attribute")
            return
        }
        attributeTxt.text = "Phones"
        var myItems : String?
        myItems = attributeTxt.text
        myItems as! AnyObject

        for ind in 0...data.count-1
        {
            let pname = data[ind].name
            if(pname == "Phones")
            {
                ParticularTree = data[ind]
                return
            }
        }
        print("parent aray=\(ParticularTree)")
        treeView.reloadData()
    }

    
    //MARK: RATreeView data source
    
    func treeView(_ treeView: RATreeView, numberOfChildrenOfItem item: Any?) -> Int
    {
        if let item = item as? DataObject {
            return item.children.count
        }
        else {
            return self.ParticularTree.children.count
        }
        return 0
    }
    
    func treeView(_ treeView: RATreeView, child index: Int, ofItem item: Any?) -> Any
    {
        if let item = item as? DataObject {
            return item.children[index]
        }
        else {
            return ParticularTree.children[index] as AnyObject
        }
        return ""

    }
    
    func treeView(_ treeView: RATreeView, cellForItem item: Any?) -> UITableViewCell {
        let cell = treeView.dequeueReusableCell(withIdentifier: String(describing: TreeTableViewCell.self)) as! TreeTableViewCell
        let item = item as! DataObject
        
        let level = treeView.levelForCell(forItem: item)
        let detailsText = "Number of children \(item.children.count)"
        cell.selectionStyle = .none
        cell.setup(withTitle: item.name, detailsText: detailsText, level: level, additionalButtonHidden: false)
        
        cell.additionButtonActionBlock = { [weak treeView] cell in
            
            let item=(treeView?.item(for: cell) as! DataObject)
            print("item stored here=\(treeView?.item(for: cell) as! DataObject)")
            
            let stored = UIAlertController(title:"Successfully Stored", message:"Your Item is stored In\(item.name)", preferredStyle: UIAlertControllerStyle.alert)
            let action = UIAlertAction(title: "Ok", style: UIAlertActionStyle.cancel, handler:nil)
            
            stored.addAction(action)
            self.present(stored, animated: true, completion: {
                print("Pop")
            })
            
//            guard let treeView = treeView else {
//                return;
//            }
//            let item = treeView.item(for: cell) as! DataObject
//            let newItem = DataObject(name: "Item Stored Here")
//            item.addChild(newItem)
//            treeView.insertItems(at: IndexSet(integer: item.children.count-1), inParent: item, with: RATreeViewRowAnimationNone);
////            treeView.reloadRows(forItems: [item], with: RATreeViewRowAnimationNone)
        }
        return cell
    }
    
    //MARK: RATreeView delegate
    
    func treeView(_ treeView: RATreeView, commit editingStyle: UITableViewCellEditingStyle, forRowForItem item: Any) {
        guard editingStyle == .delete else { return; }
        let item = item as! DataObject
        let parent = treeView.parent(forItem: item) as? DataObject
        
        let index: Int
        if let parent = parent {
            index = parent.children.index(where: { dataObject in
                return dataObject === item
            })!
            parent.removeChild(item)
            
        } else {
            index = self.data.index(where: { dataObject in
                return dataObject === item;
            })!
            self.data.remove(at: index)
        }
        
        self.treeView.deleteItems(at: IndexSet(integer: index), inParent: parent, with: RATreeViewRowAnimationRight)
        if let parent = parent {
            self.treeView.reloadRows(forItems: [parent], with: RATreeViewRowAnimationNone)
        }
    }
    
    static func commonInit() -> [DataObject] {
        let phone1 = DataObject(name: "Phone 1")
        let device1 = DataObject(name: "Device 1")
        
        //        let phone11 = DataObject(name: "Devies",children:[device1])
        
        
        let phone2 = DataObject(name: "Phone 2")
        let phone3 = DataObject(name: "Phone 3")
        let phone4 = DataObject(name: "Phone 4")
        let phones = DataObject(name: "Phones", children: [phone1, phone2, phone3, phone4])
        
        
        let notebook1 = DataObject(name: "Notebook 1")
        let notebook2 = DataObject(name: "Notebook 2")
        
        let computer1 = DataObject(name: "Computer 1", children: [notebook1, notebook2])
        let computer2 = DataObject(name: "Computer 2")
        let computer3 = DataObject(name: "Computer 3")
        let computers = DataObject(name: "Computers", children: [computer1, computer2, computer3])
        
        let cars = DataObject(name: "Cars")
        let bikes = DataObject(name: "Bikes")
        let houses = DataObject(name: "Houses")
        let flats = DataObject(name: "Flats")
        let motorbikes = DataObject(name: "motorbikes")
        let drinks = DataObject(name: "Drinks")
        let food = DataObject(name: "Food")
        let sweets = DataObject(name: "Sweets")
        let watches = DataObject(name: "Watches")
        let walls = DataObject(name: "Walls")
        
        return [phones, computers, cars,
                bikes, houses, flats, motorbikes, drinks, food, sweets, watches, walls]
    }
}
