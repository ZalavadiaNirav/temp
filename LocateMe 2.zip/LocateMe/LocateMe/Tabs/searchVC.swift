//
//  searchVC.swift
//  LocateMe
//
//  Created by Nirav Zalavadia on 12/06/18.
//  Copyright © 2018 CNSoftNetIndiaPvtLTD. All rights reserved.
//

import UIKit

class searchVC: UIViewController,UISearchBarDelegate {

    @IBOutlet weak var searchBar: UISearchBar!
    let propertyArr = NSArray(objects: "Residential","Commercial","Buy","Rent")
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        searchBar.delegate=self
      
    }
    func researchCaracters(stringSearched: String, stringQueried: String) -> Bool {
        return ((stringQueried.range(of: stringSearched, options: String.CompareOptions.caseInsensitive, range: nil, locale: nil)) != nil)
    }
    
    public func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String)
    {
        for item in propertyArr {
            if(researchCaracters(stringSearched:searchText, stringQueried: item as! String)){
                print("suggested array=\(item)")
//                suggestionListFiltredTmp.append(item)
            }
        }
    }

   
    
//    public func searchBar(_ searchBar: UISearchBar, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool
//    {
//
//
//        return true
//    }
//
//    public func searchBarSearchButtonClicked(_ searchBar: UISearchBar)
//    {
//
//    }
//
//     public func searchBarResultsListButtonClicked(_ searchBar: UISearchBar)
//    {
//
//    }

   
        // Dispose of any resources that can be recreated.
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
