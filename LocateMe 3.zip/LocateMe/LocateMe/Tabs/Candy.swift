//
//  Cnady.swift
//  LocateMe
//
//  Created by Nirav Zalavadia on 12/06/18.
//  Copyright © 2018 CNSoftNetIndiaPvtLTD. All rights reserved.
//

import Foundation

import Foundation

struct Candy {
    let category : String
    let name : String
    let attribute : NSArray
}
