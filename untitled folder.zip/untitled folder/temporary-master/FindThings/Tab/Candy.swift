//
//  Candy.swift
//  FindThings
//
//  Created by Nirav Zalavadia on 15/06/18.
//  Copyright © 2018 Gaurav Amrutiya. All rights reserved.
//

import Foundation

struct Candy {
    let category : String
    let name : String
    let attribute : NSArray
}
