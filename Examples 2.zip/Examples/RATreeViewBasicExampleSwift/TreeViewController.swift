//
//  TreeViewController.swift
//  RATreeViewExamples
//
//  Created by Rafal Augustyniak on 21/11/15.
//  Copyright © 2015 com.Augustyniak. All rights reserved.
//


import UIKit
import RATreeView



indirect enum Type {
    case number(Int,Int)
    case addParent()
    case addChild()
}

class TreeViewController: UIViewController, RATreeViewDelegate, RATreeViewDataSource {

    var treeView : RATreeView!
    var data : [DataObject]
    var editButton : UIBarButtonItem!
    var childArr = NSMutableArray()
    var parentArr = NSMutableArray()
    

    convenience init() {
        self.init(nibName : nil, bundle: nil)
    }

    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        data = TreeViewController.commonInit()
      
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
    }

    required init?(coder aDecoder: NSCoder) {
        data = TreeViewController.commonInit()
      
        super.init(coder: aDecoder)
    }
    
    func iterateparent()
    {
        for item in data
        {
            if let item = item as? DataObject
            {
                var childDict = NSMutableDictionary()
                childDict.setObject(item.name, forKey: "name" as NSCopying)
//                parentArr.add(item.name)
                if(item.children.count != 0)
                {
                    var childArr = self.iteratechild(child:item.children)
                    childDict.setObject(childArr, forKey:"child" as NSCopying)
                    parentArr.add(childDict)

                }
                else
                {
                    var arr = NSArray()
                    childDict.setObject(arr, forKey:"child" as NSCopying)
                    parentArr.add(childDict)
                }
            }
        }
        print("parent array = \(parentArr)")
    }
    
    func iteratechild(child:[DataObject]) -> NSMutableArray
    {
        var childDict = NSMutableDictionary()
        childArr = NSMutableArray()
        for item in child
        {
            childArr.addObjects(from:([item.name as Any]))
//            print("child=\(item.name)")
//            childDict.setObject(childArr, forKey:"child" as NSCopying)
        }
        return childArr
    }
    
    
    func addParent(x:Int,y:Int,name:String)
    {
        print("parent=\(name)")
    }
    
    func addChild(cx:Int,cy:Int,name:String)
    {
        print("child=\(name)")
    }
    
    //    func addBtn(x,y)
    //    {
    //        let item=p.children
    //        print
    //        if(item.children>0)
    //        addBtn(x,y)
    //    }
    
    
    
    
    func extractChild(child:[DataObject],Px:Int, Py: inout Int)
    {
        var y=Py+30
        var x=Px+10
        for index in 0...child.count-1
        {
            let parent = child[index]
            let parentBtn = UIButton()
            print("\(parent.name) x=\(x) y=\(y)")
            parentBtn.setTitle("\(parent.name)", for: .normal)
            parentBtn.setTitleColor(UIColor.blue, for: .normal)
            parentBtn.frame = CGRect(x: x, y: y, width: 100, height: 20)
            //            parentBtn.addTarget(self, action: #selector(myClass.pressed(_:)), forControlEvents: .TouchUpInside)
            self.view.addSubview(parentBtn)
            let subchild:[DataObject] = parent.children
            
            if(subchild.count != 0)
            {
                x=x+10
                extractChild(child: subchild, Px: x, Py: &y)
            }
            else
            {
                y=y+30
                Py=y
            }
        }
    }

    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        self.iterateparent()
        
        self.view.backgroundColor=UIColor.white
        let x:Int = 10
        var y:Int = 80
        self.extractChild(child: data, Px: x, Py:  &y)
        
        /*
        var px:Int = 10
        var py:Int = 80
        for parent in data
        {
            self.addParent(x: px, y: py, name: parent.name)
            let parentBtn = UIButton()
            parentBtn.setTitle("\(parent.name)", for: .normal)
            parentBtn.setTitleColor(UIColor.blue, for: .normal)
            parentBtn.frame = CGRect(x: px, y: py, width: 100, height: 20)
//            parentBtn.addTarget(self, action: #selector(myClass.pressed(_:)), forControlEvents: .TouchUpInside)
            self.view.addSubview(parentBtn)
//            print("\(parent.name)")
            let child = parent.children
            var cx:Int=px+10
            var cy:Int=py+30
            print("cx=\(cx) cy=\(cy)")
            if(child.count != 0)
            {
                
                for i in 0...child.count-1
                {
                   
                    print("inner cx=\(cx) cy=\(cy)")

                    let childBtn = UIButton()
                    childBtn.setTitle("-\(child[i].name)", for: .normal)
                    childBtn.setTitleColor(UIColor.red, for: .normal)
                    childBtn.frame = CGRect(x: cx, y: cy, width: 100, height: 20)
                    //            childBtn.addTarget(self, action: #selector(myClass.pressed(_:)), forControlEvents: .TouchUpInside)
                    self.view.addSubview(childBtn)
                    cy=cy+30
                    py=cy
                    px=cx+10
//                    print(" -\(child[i].name)")
                }
            }
            else
            {
               py=cy
            }

        }
 */
//        view.backgroundColor = .white
//
//        title = "Things"
//        setupTreeView()
//        updateNavigationBarButtons()
    }

    func setupTreeView() -> Void {
        treeView = RATreeView(frame: view.bounds)
        treeView.register(UINib(nibName: String(describing: TreeTableViewCell.self), bundle: nil), forCellReuseIdentifier: String(describing: TreeTableViewCell.self))
        treeView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        treeView.delegate = self;
        treeView.dataSource = self;
        treeView.treeFooterView = UIView()
        treeView.backgroundColor = .clear
        view.addSubview(treeView)
    }

    func updateNavigationBarButtons() -> Void {
        let systemItem = treeView.isEditing ? UIBarButtonSystemItem.done : UIBarButtonSystemItem.edit;
        self.editButton = UIBarButtonItem(barButtonSystemItem: systemItem, target: self, action: #selector(TreeViewController.editButtonTapped(_:)))
        self.navigationItem.rightBarButtonItem = self.editButton;
    }

    func editButtonTapped(_ sender: AnyObject) -> Void {
        
        let walls = DataObject(name: "wills")
        data.append(walls)
        
//        let newItem = DataObject(name: "wills")
//        treeView.insertItems(at: IndexSet(integer:0), inParent: newItem, with: RATreeViewRowAnimationNone);
        treeView.reloadData()
        

    }


    //MARK: RATreeView data source

    func treeView(_ treeView: RATreeView, numberOfChildrenOfItem item: Any?) -> Int {
        if let item = item as? DataObject {
            return item.children.count
        } else {
            return self.data.count
        }
    }

    func treeView(_ treeView: RATreeView, child index: Int, ofItem item: Any?) -> Any {
        if let item = item as? DataObject {
            return item.children[index]
        } else {
            return data[index] as AnyObject
        }
    }

    func treeView(_ treeView: RATreeView, cellForItem item: Any?) -> UITableViewCell {
        let cell = treeView.dequeueReusableCell(withIdentifier: String(describing: TreeTableViewCell.self)) as! TreeTableViewCell
        let item = item as! DataObject

        let level = treeView.levelForCell(forItem: item)
        let detailsText = "Number of children \(item.children.count)"
        cell.selectionStyle = .none
        cell.setup(withTitle: item.name, detailsText: detailsText, level: level, additionalButtonHidden: false)
        cell.additionButtonActionBlock = { [weak treeView] cell in
            guard let treeView = treeView else {
                return;
            }
            let item = treeView.item(for: cell) as! DataObject
            let newItem = DataObject(name: "Added value")
            item.addChild(newItem)
            treeView.insertItems(at: IndexSet(integer: item.children.count-1), inParent: item, with: RATreeViewRowAnimationNone);
            treeView.reloadRows(forItems: [item], with: RATreeViewRowAnimationNone)
        }
        return cell
    }

    //MARK: RATreeView delegate

    func treeView(_ treeView: RATreeView, commit editingStyle: UITableViewCellEditingStyle, forRowForItem item: Any) {
        guard editingStyle == .delete else { return; }
        let item = item as! DataObject
        let parent = treeView.parent(forItem: item) as? DataObject

        let index: Int
        if let parent = parent {
            index = parent.children.index(where: { dataObject in
                return dataObject === item
            })!
            parent.removeChild(item)

        } else {
            index = self.data.index(where: { dataObject in
                return dataObject === item;
            })!
            self.data.remove(at: index)
        }

        self.treeView.deleteItems(at: IndexSet(integer: index), inParent: parent, with: RATreeViewRowAnimationRight)
        if let parent = parent {
            self.treeView.reloadRows(forItems: [parent], with: RATreeViewRowAnimationNone)
        }
    }
}




private extension TreeViewController {

    static func commonInit() -> [DataObject] {
        let phone1 = DataObject(name: "Phone 1")
        let device1 = DataObject(name: "Device 1")
        
//        let phone11 = DataObject(name: "Devies",children:[device1])
        
        
        let phone2 = DataObject(name: "Phone 2")
        let phone3 = DataObject(name: "Phone 3")
        let phone4 = DataObject(name: "Phone 4")
        let phones = DataObject(name: "Phones", children: [phone1, phone2, phone3, phone4])
        
        
        let notebook1 = DataObject(name: "Notebook 1")
        let notebook2 = DataObject(name: "Notebook 2")

        let computer1 = DataObject(name: "Computer 1", children: [notebook1, notebook2])
        let computer2 = DataObject(name: "Computer 2")
        let computer3 = DataObject(name: "Computer 3")
        let computers = DataObject(name: "Computers", children: [computer1, computer2, computer3])

        let cars = DataObject(name: "Cars")
        let bikes = DataObject(name: "Bikes")
        let houses = DataObject(name: "Houses")
        let flats = DataObject(name: "Flats")
        let motorbikes = DataObject(name: "motorbikes")
        let drinks = DataObject(name: "Drinks")
        let food = DataObject(name: "Food")
        let sweets = DataObject(name: "Sweets")
        let watches = DataObject(name: "Watches")
        let walls = DataObject(name: "Walls")

        return [phones, computers, cars,
                bikes, houses, flats, motorbikes, drinks, food, sweets, watches, walls]
    }

}

