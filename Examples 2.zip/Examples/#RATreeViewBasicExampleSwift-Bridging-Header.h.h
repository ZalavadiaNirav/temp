//
//  Objective-CBridgingHeader.h
//  
//
//  Created by Nirav Zalavadia on 08/06/18.
//

#ifndef Objective_CBridgingHeader_h
#define Objective_CBridgingHeader_h

#import "RADataObject.h"
#import "customObject.h"

#endif /* Objective_CBridgingHeader_h */
