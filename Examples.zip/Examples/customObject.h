//
//  customObject.h
//  
//
//  Created by Nirav Zalavadia on 08/06/18.
//

#import <Foundation/Foundation.h>

@interface customObject : NSObject

@property (strong, nonatomic) NSString *name;
@property (strong, nonatomic) NSArray *children;

- (id)initWithName:(NSString *)name children:(NSArray *)array;

+ (id)dataObjectWithName:(NSString *)name children:(NSArray *)children;

- (void)addChild:(id)child;
- (void)removeChild:(id)child;

@end
